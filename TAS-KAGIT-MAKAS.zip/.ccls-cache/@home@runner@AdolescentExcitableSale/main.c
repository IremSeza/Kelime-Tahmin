#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int oyuncu, bilgisayar;

    printf("=== Taş, Kağıt, Makas ===\n");
    printf("Seçenekler: 0 = Taş, 1 = Kağıt, 2 = Makas\n");

    srand(time(NULL));

    printf("Seçiminizi yapın (0 = Taş, 1 = Kağıt, 2 = Makas): ");
    scanf("%d", &oyuncu);

    if (oyuncu < 0 || oyuncu > 2) {
        printf("Yanlış seçim! Lütfen 0, 1 veya 2 girin.\n");
        return 1;
    }

    bilgisayar = rand() % 3;

    printf("Siz: %s, Bilgisayar: %s\n",
           (oyuncu == 0 ? "Taş" : oyuncu == 1 ? "Kağıt" : "Makas"),
           (bilgisayar == 0 ? "Taş" : bilgisayar == 1 ? "Kağıt" : "Makas"));
 
    if (oyuncu == bilgisayar) {
        printf("Berabere!\n");
    } else if ((oyuncu == 0 && bilgisayar == 2) ||  // Taş > Makas
               (oyuncu == 1 && bilgisayar == 0) ||  // Kağıt > Taş
               (oyuncu == 2 && bilgisayar == 1)) {  // Makas > Kağıt
        printf("Kazandınız!\n");
    } else {
        printf("Kaybettiniz!\n");
    }

    return 0;
}