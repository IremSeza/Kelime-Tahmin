#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

// Sığınak yapısı
typedef struct {
    int su;
    int yemek;
    int moral;
    int IlkYardimKiti;
    int suGunleri;  // Su bitince kaç gün dayanılabilir
    int yemekGunleri;  // Yemek bitince kaç gün dayanılabilir
} Siginak;

// Rastgele olay metinleri
const char* olaylar[] = {
    "Birisi su istiyor. Su verecek misiniz?",
    "Bir aile üyesi yemek istiyor. Yemek verecek misiniz?",
    "Sığınakta sessizlik hakim. Bugün bir şey yapmak ister misiniz?",
    "Birisi hastalandı. İlk yardım kiti vermek ister misiniz?",
    "Birisi yaralandı. İlk yardım kiti vermek ister misiniz?"
};

void kaynakDurumuGoster(Siginak* siginak) {
    printf("\n--- Kaynak Durumu ---\n");
    printf("Su: %d (Su bitince dayanma süresi: %d gün)\n", siginak->su, siginak->suGunleri);
    printf("Yemek: %d (Yemek bitince dayanma süresi: %d gün)\n", siginak->yemek, siginak->yemekGunleri);
    printf("Ilk Yardim Kiti: %d\n", siginak->IlkYardimKiti);
    printf("Moral: %d\n", siginak->moral);
     printf("---------------------\n");
}

void clearScreen() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

// Oyun durumu kontrolü
int oyunDurumu(Siginak* siginak) {
    if (siginak->moral <= 0) {
        printf("\nMoral sıfıra düştü! Hayatta kalamadınız.\n");
        return 0;
    }
    if (siginak->su <= 0) {
        siginak->suGunleri--;
        if (siginak->suGunleri <= 0) {
            printf("\nSu tükendi ve dayanma süresi doldu! Hayatta kalamadınız.\n");
            return 0;
        }
    }
    if (siginak->yemek <= 0) {
        siginak->yemekGunleri--;
        if (siginak->yemekGunleri <= 0) {
            printf("\nYemek tükendi ve dayanma süresi doldu! Hayatta kalamadınız.\n");
            return 0;
        }
    }
    return 1; // Oyun devam ediyor
}

// Olay yönetimi ve seçim mekaniği
void olaySecimi(Siginak* siginak, int olay) {
    char secim;
    printf("%s (E/H): ", olaylar[olay]);
    scanf(" %c", &secim);

    if (secim == 'E' || secim == 'e') {
        if (olay == 0) { // Su isteyen olay
            if (siginak->su > 0) {
                siginak->su--;
                printf("Bir şişe su verdiniz. Kalan su: %d\n", siginak->su);
            } else {
                printf("Suyunuz yok! Kimseye su veremediniz.\n");
            }
        } else if (olay == 1) { // Yemek isteyen olay
            if (siginak->yemek > 0) {
                siginak->yemek--;
                printf("Bir öğün yemek verdiniz. Kalan yemek: %d\n", siginak->yemek);
            } else {
                printf("Yemeğiniz yok! Kimseye yemek veremediniz.\n");
            }
        } else if (olay == 2) { // Sessiz gün seçeneği
            siginak->moral += 5;
            printf("Sakin ve huzurlu bir gün geçirdiniz. Moral arttı! Moral: %d\n", siginak->moral);
        } else if (olay == 3) { // İlk yardım kiti veren olay
            if (siginak->IlkYardimKiti > 0) {
                siginak->IlkYardimKiti--;
                siginak->moral += 10;
                printf("Hastalar iyileşti. Moral arttı! Moral: %d\n", siginak->moral);
            } else {
                printf("İlk yardım kitiniz yok! Kimseye yardım edemediniz.\n");
            }
        }
    } else {
        if (olay == 0 || olay == 1) {
            printf("Hiçbir şey yapmadınız. Bugün sakin geçti.\n");
        } else {
            siginak->moral -= 5;
            printf("Bir şey yapmadığınız için moral düştü! Moral: %d\n", siginak->moral);
        }
    }
}

void disariCik(Siginak* siginak) {
    int rastgeleKaynak = rand() % 3; // 0: Su, 1: Yemek, 2: İlk Yardım Kiti
    int miktar = rand() % 3 + 1;    // 1 ile 3 arasında miktar

    const char* kaynaklar[] = {"Su", "Yemek", "İlk Yardım Kiti"};

    printf("\nDışarı çıktınız ve %d adet %s buldunuz!\n", miktar, kaynaklar[rastgeleKaynak]);
    if (rastgeleKaynak == 0) siginak->su += miktar;
    else if (rastgeleKaynak == 1) siginak->yemek += miktar;
    else if (rastgeleKaynak == 2) siginak->IlkYardimKiti += miktar;

    // Moralin düşmesi
    siginak->moral -= 10;
    printf("Dışarı çıktınız ve etraftaki durumdan dolayı moraliniz düştü. Yeni moral: %d\n", siginak->moral);
}

void hayattaKalmaAsamasi(Siginak* siginak) {
    printf("\nHayatta kalma aşaması başladı!\n");
    int gun = 1;
    while (1) {
        printf("\nGün %d:\n", gun);
        // Rastgele bir olay seçimi
        int olay = rand() % 4;
        olaySecimi(siginak, olay);

        kaynakDurumuGoster(siginak);

        // Dışarı çıkma seçeneği
        char secim;
        printf("Dışarı çıkmak ister misiniz? (E/H): ");
        scanf(" %c", &secim);
        if (secim == 'E' || secim == 'e') {
            disariCik(siginak);
        }

        // Oyun durumu kontrolü
        if (!oyunDurumu(siginak)) {
            return; // Oyun biter
        }

        gun++;
    }
}

void toplamaAsamasi(Siginak* siginak) {
    int zaman = 60; // Kalan süre
    char secim;
    const char* kaynaklar[] = {"Su", "Yemek", "İlk Yardım Kiti"};

    printf("60 saniyen var! Ne toplayabilirsin?\n");
    while (zaman > 0) {
        int rastgeleKaynak = rand() % 3; // 0: Su, 1: Yemek, 2: İlk Yardım Kiti
        int miktar = rand() % 3 + 1;    // 1 ile 3 arasında miktar

        printf("\nBulunan: %s (%d adet)\n", kaynaklar[rastgeleKaynak], miktar);
        printf("Toplamak için 'E', geçmek için 'H' gir: ");
        scanf(" %c", &secim);

        if (secim == 'E' || secim == 'e') {
            if (rastgeleKaynak == 0) siginak->su += miktar;
            else if (rastgeleKaynak == 1) siginak->yemek += miktar;
            else if (rastgeleKaynak == 2) siginak->IlkYardimKiti += miktar;
            zaman -= 10; // Toplama süresi
            clearScreen();
            printf("Kaynak toplandı! Kalan süre: %d saniye\n", zaman);

        } else {
            zaman -= 5; // Geçme süresi
            clearScreen();
            printf("Kalan süre: %d saniye\n", zaman);

        }
    }

    printf("\nToplama aşaması sona erdi!\n");
    printf("Toplananlar - Su: %d, Yemek: %d, İlk Yardım kiti: %d, Moral: %d\n", siginak->su, siginak->yemek, siginak->IlkYardimKiti, siginak->moral);
}

// Ana fonksiyon
int main() {
    srand(time(NULL)); // Rastgelelik için başlangıç
    Siginak siginak = {0, 0, 50, 0, 3, 5}; // Başlangıç durumu (3 gün susuz, 5 gün yemeksiz dayanabilir)

    printf("*60 Saniye Oyunu*\n");
    toplamaAsamasi(&siginak);
    hayattaKalmaAsamasi(&siginak);

    printf("\nOyun bitti! Teşekkürler.\n");
    return 0;
}
